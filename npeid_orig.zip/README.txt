Network PeID

Usage:

To Scan a pcap
./npeid.py name.pcap

To Scan an interface
./npeid.py


Requirements:

pynids (make sure you get this one and not the older one)
http://jon.oberheide.org/projects/pynids/downloads/pynids-0.5a.tar.gz

pefile
http://pefile.googlecode.com/files/pefile-1.2.10-63.tar.gz

libnet
libpcap
libglib
python2.x-dev