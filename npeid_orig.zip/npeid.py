#! /usr/bin/python
import os,sys,nids,re,pefile,peutils

end_states = (nids.NIDS_CLOSE, nids.NIDS_TIMEOUT, nids.NIDS_RESET)
signatures = peutils.SignatureDatabase('UserDB.TXT')

def handleTcpStream(tcp):
	#print "tcps -", str(tcp.addr), " state:", tcp.nids_state
	if tcp.nids_state == nids.NIDS_JUST_EST:
		((src, sport), (dst, dport)) = tcp.addr
		if dport in (80, 8000, 8080):
			tcp.client.collect = 1
			tcp.server.collect = 1
	elif tcp.nids_state == nids.NIDS_DATA:
		tcp.discard(0)
	elif tcp.nids_state in end_states:
		toserver = tcp.server.data[:tcp.server.count]
		toclient = tcp.client.data[:tcp.client.count]
		header_len = toclient.find('\r\n\r\n')
		toclient_body = toclient[header_len+4:]
		pe = pefile.PE(data=toclient_body)
		matches = signatures.match_all(pe, ep_only = True)
		for match in matches:
			print match

def main():
	nids.param("scan_num_hosts", 0)
	if len(sys.argv) == 2:
		nids.param("filename", sys.argv[1])
	else:
		nids.param("device", "eth0")

	nids.init()
	nids.register_tcp(handleTcpStream)
	try:
		nids.run()
	except nids.error, e:
		print "nids/pcap error:", e
	except Exception, e:
		print "misc. exception (runtime error in user callback?):", e

if __name__ == '__main__':
	main()

